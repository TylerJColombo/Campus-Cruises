#if !defined(__has_feature) || !__has_feature(objc_arc)
#error "This file requires ARC support."
#endif

#import "SDKDemos/Samples/PanoramaViewController.h"

#import <GoogleMapsM4B/GoogleMaps.h>

static CLLocationCoordinate2D kPanoramaNear = {40.761388, -73.978133};
static CLLocationCoordinate2D kMarkerAt = {40.761455, -73.977814};

@interface PanoramaViewController () <GMSPanoramaViewDelegate>
@end

@implementation PanoramaViewController {
  GMSPanoramaView *_view;
  BOOL _configured;
  UILabel *_statusLabel;
}

- (void)viewDidLoad {
  [super viewDidLoad];

  _view = [GMSPanoramaView panoramaWithFrame:CGRectZero
                              nearCoordinate:kPanoramaNear];
  _view.backgroundColor = [UIColor grayColor];
  _view.delegate = self;
  self.view = _view;

  // Add status label, initially hidden.
  _statusLabel = [[UILabel alloc] initWithFrame:CGRectMake(0, 0, 0, 30)];
  _statusLabel.alpha = 0.0f;
  _statusLabel.autoresizingMask = UIViewAutoresizingFlexibleWidth;
  _statusLabel.backgroundColor = [UIColor blueColor];
  _statusLabel.textColor = [UIColor whiteColor];
  _statusLabel.textAlignment = NSTextAlignmentCenter;

  [_view addSubview:_statusLabel];
}

#pragma mark - GMSPanoramaDelegate

- (void)panoramaView:(GMSPanoramaView *)panoramaView
       didMoveCamera:(GMSPanoramaCamera *)camera {
  NSLog(@"Camera: (%f,%f,%f)",
        camera.orientation.heading, camera.orientation.pitch, camera.zoom);
}

- (void)panoramaView:(GMSPanoramaView *)view
   didMoveToPanorama:(GMSPanorama *)panorama {
  if (!_configured) {
    GMSMarker *marker = [GMSMarker markerWithPosition:kMarkerAt];
    marker.icon = [GMSMarker markerImageWithColor:[UIColor purpleColor]];
    marker.panoramaView = _view;

    CLLocationDegrees heading = GMSGeometryHeading(kPanoramaNear, kMarkerAt);
    _view.camera =
        [GMSPanoramaCamera cameraWithHeading:heading pitch:0 zoom:1];

    _configured = YES;
  }
}

- (void)panoramaViewDidStartRendering:(GMSPanoramaView *)panoramaView {
  _statusLabel.alpha = 0.8f;
  _statusLabel.text = @"Rendering";
}

- (void)panoramaViewDidFinishRendering:(GMSPanoramaView *)panoramaView {
  _statusLabel.alpha = 0.0f;
}

@end
