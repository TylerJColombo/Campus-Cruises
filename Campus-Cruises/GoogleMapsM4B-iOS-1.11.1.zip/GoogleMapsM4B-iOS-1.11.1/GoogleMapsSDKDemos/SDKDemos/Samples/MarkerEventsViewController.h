#import <UIKit/UIKit.h>

#import <GoogleMapsM4B/GoogleMaps.h>

@interface MarkerEventsViewController : UIViewController <GMSMapViewDelegate>

@end
