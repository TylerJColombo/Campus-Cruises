#import <UIKit/UIKit.h>

#import <GoogleMapsM4B/GoogleMaps.h>

@interface IndoorMuseumNavigationViewController : UIViewController<
  GMSMapViewDelegate,
  GMSIndoorDisplayDelegate>

@end
