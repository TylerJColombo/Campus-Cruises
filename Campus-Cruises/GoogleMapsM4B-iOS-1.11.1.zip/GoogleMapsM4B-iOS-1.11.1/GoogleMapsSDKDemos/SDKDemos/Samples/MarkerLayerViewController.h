#import <UIKit/UIKit.h>

#import <GoogleMapsM4B/GoogleMaps.h>

@interface MarkerLayerViewController : UIViewController<GMSMapViewDelegate>

@end
