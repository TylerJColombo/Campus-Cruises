
#import <CoreLocation/CoreLocation.h>
#import <UIKit/UIKit.h>

#import <GoogleMapsM4B/GoogleMaps.h>

@interface AnimatedCurrentLocationViewController : UIViewController<CLLocationManagerDelegate>

@end
